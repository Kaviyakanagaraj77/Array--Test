# Array Test - Java Practice

Basic Java array programs for test preparation.

## Programs

1. Even numbers
2. Print array
3. Linear search
4. Binary search
5. Sum, average, minimum and maximum
6. Reverse array
7. Count and print odd/even numbers
8. Bubble sort

## Run

Compile:
`javac FileName.java`

Run:
`java ClassName`
